# assets/

This first version of the add-on has no external asset dependencies —
the "tree" instanced onto scattered points is a small cone mesh built at
runtime in `utils.get_or_create_tree_proxy()`, so the add-on works right
after installation with nothing to import.

This folder is reserved for future weeks: drop in `.blend` files with real
tree/rock/building assets here, then update `generator.py`'s
`GeometryNodeObjectInfo` source to point at an asset from this folder
instead of the placeholder cone.
