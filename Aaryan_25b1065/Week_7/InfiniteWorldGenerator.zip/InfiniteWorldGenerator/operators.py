"""
operators.py
============

Operators are the actions behind every button in the panel (this week's
"Blender Operators" topic). Each one does exactly one job and reports back
to the user through Blender's info log via self.report(...).
"""

import random

import bpy

from . import generator


class WORLDGEN_OT_generate(bpy.types.Operator):
    """Read the current settings, push them into Geometry Nodes, and (re)build the world"""
    bl_idname = "world.generate"
    bl_label = "Generate World"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = generator.generate_world(context)

        # Make the freshly (re)generated terrain easy to see/select.
        for o in context.view_layer.objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({'INFO'}, f"World generated (seed {context.scene.iwg_props.seed})")
        return {'FINISHED'}


class WORLDGEN_OT_randomize_seed(bpy.types.Operator):
    """Pick a new random seed, update the UI, and regenerate the world"""
    bl_idname = "world.randomize_seed"
    bl_label = "Randomize Seed"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.iwg_props
        props.seed = random.randint(0, 999999)
        generator.generate_world(context)
        self.report({'INFO'}, f"New seed: {props.seed}")
        return {'FINISHED'}


classes = (
    WORLDGEN_OT_generate,
    WORLDGEN_OT_randomize_seed,
)
