"""
properties.py
=============

Defines every adjustable parameter shown in the Sidebar panel. This is the
single source of truth for the world's settings -- the panel just displays
these properties, and the operators just read them. Nothing here performs
generation; it only *stores* values (matches the "Blender Properties" topic
for this week: Integer, Float properties, sensible defaults).
"""

import bpy


def _on_setting_changed(self, context):
    """
    Optional live-update hook. Left as a no-op by default so Week 7's first
    version only regenerates when the user presses "Generate World" (as
    specced in the mini project). Flip `live_update` in the panel and wire
    this up to generator.generate_world() if you want real-time updates.
    """
    return None


class IWG_Properties(bpy.types.PropertyGroup):
    """All user-facing settings for the Infinite World Generator."""

    seed: bpy.props.IntProperty(
        name="Seed",
        description="Controls every random choice in the world. The same "
                    "seed always regenerates the exact same world",
        default=2025,
        min=0,
        soft_max=999999,
    )

    terrain_size: bpy.props.FloatProperty(
        name="Terrain Size",
        description="Size (in meters) of one side of the generated terrain",
        default=50.0,
        min=1.0,
        soft_max=500.0,
        unit='LENGTH',
    )

    mountain_strength: bpy.props.FloatProperty(
        name="Mountain Strength",
        description="How tall and dramatic the terrain's height variation is",
        default=10.0,
        min=0.0,
        soft_max=20.0,
    )

    tree_density: bpy.props.FloatProperty(
        name="Tree Density",
        description="Roughly how many trees are scattered per square meter",
        default=0.05,
        min=0.0,
        soft_max=1.0,
    )

    village_count: bpy.props.IntProperty(
        name="Village Count",
        description="Number of settlement points scattered across the "
                    "terrain (reserved for a future week's settlement system)",
        default=1,
        min=0,
        soft_max=10,
    )


classes = (IWG_Properties,)
