"""
Infinite World Generator
=========================

Week 7 Mini Project - First working version of the Infinite World Generator
Blender add-on.

This file is the entry point Blender loads. It never contains generation
logic itself -- it only imports the other modules and registers/unregisters
their classes. Keeping __init__.py "thin" like this is standard Blender
add-on practice and matches the modular structure taught this week:

    InfiniteWorldGenerator/
    ├── __init__.py      <- you are here (bl_info + register/unregister)
    ├── properties.py    <- adjustable settings (Seed, Terrain Size, ...)
    ├── operators.py     <- buttons: Generate World / Randomize Seed
    ├── panel.py         <- the Sidebar (N-Panel) UI
    ├── generator.py      <- builds/updates the Geometry Nodes network
    └── utils.py         <- small shared helper functions
"""

bl_info = {
    "name": "Infinite World Generator",
    "author": "Student",
    "version": (0, 1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > World Gen",
    "description": "Generate procedural infinite worlds using Geometry Nodes, "
                    "controlled entirely from a simple UI panel.",
    "category": "Add Mesh",
}

import bpy

# Import order matters a little: properties before operators/panel, since
# operators and panel both read from the properties module.
from . import properties
from . import generator
from . import operators
from . import panel

# Every module below exposes a `classes` tuple of the bpy.types classes it
# defines. Collecting them here means register()/unregister() never needs
# to be touched when a class is added to one of the sub-modules.
_modules = (properties, operators, panel)


def register():
    for module in _modules:
        for cls in module.classes:
            bpy.utils.register_class(cls)

    # Attach our PropertyGroup to the Scene so it's saved with the .blend
    # file and accessible anywhere as `scene.iwg_props`.
    bpy.types.Scene.iwg_props = bpy.props.PointerProperty(
        type=properties.IWG_Properties
    )


def unregister():
    del bpy.types.Scene.iwg_props

    for module in reversed(_modules):
        for cls in reversed(module.classes):
            bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
