"""
generator.py
============

This module is the bridge described in this week's "Connecting Python with
Geometry Nodes" topic:

    User Input -> Python Script -> Geometry Nodes Parameters -> Generated World

Python's job here is NOT to build the terrain mesh itself. Its job is to:
  1. Build the Geometry Nodes node group *once* (build_node_group), wiring
     up noise-based terrain displacement and tree scattering.
  2. On every "Generate World" press, push the current Scene properties
     (seed, terrain size, mountain strength, tree density) into that node
     group's inputs and let Geometry Nodes do the actual procedural work.

The noise approach mirrors the Week 6 chunk-based terrain generator
(seeded value/fractal noise, deterministic per-coordinate), except instead
of Python computing a height array by hand, we use Blender's built-in
Noise Texture node driven by the same (seed, position) idea: a 4D noise
where X/Y are the terrain position and W is the seed, so changing the seed
reshuffles the whole terrain exactly like `seeded_random(seed, x, y)` did
in Week 6.
"""

import bpy

from . import utils

GRID_RESOLUTION = 64  # vertices per side; fixed for this first version
SUBDIVISION_LEVEL = 2  # extra subdivisions applied before displacement, so
                        # the smoothed terrain has enough geometry to curve
                        # nicely instead of just faking it with normals


def _new_link(node_group, from_socket, to_socket):
    node_group.links.new(from_socket, to_socket)


def _add_group_inputs(node_group):
    """Create the group's public interface: what shows up as modifier inputs."""
    iface = node_group.interface

    iface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    iface.new_socket(name="Seed", in_out='INPUT', socket_type='NodeSocketInt')
    iface.new_socket(name="Terrain Size", in_out='INPUT', socket_type='NodeSocketFloat')
    iface.new_socket(name="Mountain Strength", in_out='INPUT', socket_type='NodeSocketFloat')
    iface.new_socket(name="Tree Density", in_out='INPUT', socket_type='NodeSocketFloat')

    iface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')


def build_node_group(node_group):
    """
    Wire up the full terrain + tree-scatter network from scratch. Only
    called once per node group (see ensure_node_group), so re-generating
    the world never rebuilds the graph -- it just changes input values.
    """
    nodes = node_group.nodes
    links = node_group.links
    nodes.clear()

    _add_group_inputs(node_group)

    group_in = nodes.new("NodeGroupInput")
    group_in.location = (-800, 0)

    group_out = nodes.new("NodeGroupOutput")
    group_out.location = (1500, 0)

    # --- Terrain base mesh --------------------------------------------------
    grid = nodes.new("GeometryNodeMeshGrid")
    grid.location = (-600, 200)
    grid.inputs["Vertices X"].default_value = GRID_RESOLUTION
    grid.inputs["Vertices Y"].default_value = GRID_RESOLUTION
    _new_link(node_group, group_in.outputs["Terrain Size"], grid.inputs["Size X"])
    _new_link(node_group, group_in.outputs["Terrain Size"], grid.inputs["Size Y"])

    # Subdivide before displacement so the noise has more vertices to work
    # with -- this is what actually removes the "faceted/low-poly" look,
    # since Set Shade Smooth alone only fakes smoothness on the existing
    # (coarse) triangles.
    subdivide = nodes.new("GeometryNodeSubdivideMesh")
    subdivide.location = (-450, 200)
    subdivide.inputs["Level"].default_value = SUBDIVISION_LEVEL
    _new_link(node_group, grid.outputs["Mesh"], subdivide.inputs["Mesh"])

    # --- Height noise (mirrors Week 6's seeded fractal noise) --------------
    position = nodes.new("GeometryNodeInputPosition")
    position.location = (-600, -100)

    noise = nodes.new("ShaderNodeTexNoise")
    noise.location = (-400, -100)
    noise.noise_dimensions = '4D'
    noise.inputs["Scale"].default_value = 0.3
    noise.inputs["Detail"].default_value = 4.0     # matches Week 6's OCTAVES
    noise.inputs["Roughness"].default_value = 0.5  # matches Week 6's PERSISTENCE
    _new_link(node_group, position.outputs["Position"], noise.inputs["Vector"])
    _new_link(node_group, group_in.outputs["Seed"], noise.inputs["W"])

    height_scale = nodes.new("ShaderNodeMath")
    height_scale.location = (-200, -100)
    height_scale.operation = 'MULTIPLY'
    _new_link(node_group, noise.outputs["Fac"], height_scale.inputs[0])
    _new_link(node_group, group_in.outputs["Mountain Strength"], height_scale.inputs[1])

    offset = nodes.new("ShaderNodeCombineXYZ")
    offset.location = (0, -100)
    offset.inputs["X"].default_value = 0.0
    offset.inputs["Y"].default_value = 0.0
    _new_link(node_group, height_scale.outputs["Value"], offset.inputs["Z"])

    set_position = nodes.new("GeometryNodeSetPosition")
    set_position.location = (200, 100)
    _new_link(node_group, subdivide.outputs["Mesh"], set_position.inputs["Geometry"])
    _new_link(node_group, offset.outputs["Vector"], set_position.inputs["Offset"])

    # --- Smooth shading -------------------------------------------------
    shade_smooth = nodes.new("GeometryNodeSetShadeSmooth")
    shade_smooth.location = (350, 100)
    shade_smooth.inputs["Shade Smooth"].default_value = True
    _new_link(node_group, set_position.outputs["Geometry"], shade_smooth.inputs["Geometry"])

    # --- Height-based biome color ---------------------------------------
    # Reuse the noise's 0..1 "Fac" output (relative elevation, independent
    # of the Mountain Strength multiplier) to drive a 3-stop gradient:
    # pale yellow desert at the bottom, green vegetation through the
    # middle, white snow at the top.
    biome_ramp = nodes.new("ShaderNodeValToRGB")
    biome_ramp.location = (350, -250)
    ramp = biome_ramp.color_ramp
    ramp.elements[0].position = 0.0
    ramp.elements[0].color = (0.87, 0.75, 0.45, 1.0)   # pale yellow desert
    ramp.elements[1].position = 0.55
    ramp.elements[1].color = (0.22, 0.42, 0.14, 1.0)   # green vegetation
    snow_stop = ramp.elements.new(0.8)
    snow_stop.color = (0.95, 0.95, 0.97, 1.0)          # white snow
    _new_link(node_group, noise.outputs["Fac"], biome_ramp.inputs["Fac"])

    store_biome_color = nodes.new("GeometryNodeStoreNamedAttribute")
    store_biome_color.location = (550, 100)
    store_biome_color.domain = 'POINT'
    store_biome_color.data_type = 'FLOAT_COLOR'
    store_biome_color.inputs["Name"].default_value = "Biome"
    _new_link(node_group, shade_smooth.outputs["Geometry"], store_biome_color.inputs["Geometry"])
    _new_link(node_group, biome_ramp.outputs["Color"], store_biome_color.inputs["Value"])

    set_material = nodes.new("GeometryNodeSetMaterial")
    set_material.location = (700, 100)
    set_material.inputs["Material"].default_value = utils.get_or_create_biome_material()
    _new_link(node_group, store_biome_color.outputs["Geometry"], set_material.inputs["Geometry"])

    # --- Tree scattering -----------------------------------------------------
    distribute = nodes.new("GeometryNodeDistributePointsOnFaces")
    distribute.location = (900, -200)
    distribute.distribute_method = 'RANDOM'
    _new_link(node_group, set_material.outputs["Geometry"], distribute.inputs["Mesh"])
    _new_link(node_group, group_in.outputs["Tree Density"], distribute.inputs["Density"])
    _new_link(node_group, group_in.outputs["Seed"], distribute.inputs["Seed"])

    tree_object_info = nodes.new("GeometryNodeObjectInfo")
    tree_object_info.location = (900, -400)
    tree_proxy = utils.get_or_create_tree_proxy()
    tree_object_info.inputs["Object"].default_value = tree_proxy
    tree_object_info.transform_space = 'RELATIVE'

    instance = nodes.new("GeometryNodeInstanceOnPoints")
    instance.location = (1100, -200)
    _new_link(node_group, distribute.outputs["Points"], instance.inputs["Points"])
    _new_link(node_group, tree_object_info.outputs["Geometry"], instance.inputs["Instance"])

    # --- Combine terrain + trees, output ------------------------------------
    join = nodes.new("GeometryNodeJoinGeometry")
    join.location = (1300, 0)
    _new_link(node_group, set_material.outputs["Geometry"], join.inputs["Geometry"])
    _new_link(node_group, instance.outputs["Instances"], join.inputs["Geometry"])
    _new_link(node_group, join.outputs["Geometry"], group_out.inputs["Geometry"])


def ensure_node_group() -> bpy.types.NodeTree:
    """Return the world-generator node group, building it once if missing."""
    node_group = bpy.data.node_groups.get(utils.NODE_GROUP_NAME)
    if node_group is None:
        node_group = bpy.data.node_groups.new(utils.NODE_GROUP_NAME, "GeometryNodeTree")
        build_node_group(node_group)
    return node_group


def ensure_terrain_object() -> bpy.types.Object:
    """Return the terrain object, attaching the generator modifier if needed."""
    obj = utils.get_or_create_object(utils.TERRAIN_OBJECT_NAME)
    node_group = ensure_node_group()

    modifier = obj.modifiers.get(utils.MODIFIER_NAME)
    if modifier is None:
        modifier = obj.modifiers.new(utils.MODIFIER_NAME, type='NODES')
    modifier.node_group = node_group
    return obj


def generate_world(context) -> bpy.types.Object:
    """
    The core of the "Generate World" button: read the Scene's iwg_props and
    push them into the Geometry Nodes modifier, then ask Blender to
    re-evaluate the object.
    """
    props = context.scene.iwg_props
    obj = ensure_terrain_object()
    modifier = obj.modifiers[utils.MODIFIER_NAME]

    utils.set_group_input(modifier, "Seed", props.seed)
    utils.set_group_input(modifier, "Terrain Size", props.terrain_size)
    utils.set_group_input(modifier, "Mountain Strength", props.mountain_strength)
    utils.set_group_input(modifier, "Tree Density", props.tree_density)

    obj.update_tag()
    context.view_layer.update()
    return obj
