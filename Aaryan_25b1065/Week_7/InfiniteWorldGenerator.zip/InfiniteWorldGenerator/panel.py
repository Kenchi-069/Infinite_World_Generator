"""
panel.py
========

Builds the custom N-Panel described in this week's "Blender UI Panels"
topic. This module only lays out widgets -- it never generates anything
itself; it just displays iwg_props and calls the operators.

Layout matches the mini-project spec:

    Infinite World Generator
    ------------------------
    Seed
    Terrain Size
    Mountain Strength
    Tree Density
    [ Generate World ]
    [ Randomize Seed ]
"""

import bpy


class WORLDGEN_PT_main_panel(bpy.types.Panel):
    bl_label = "Infinite World Generator"
    bl_idname = "WORLDGEN_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "World Gen"  # tab name in the Sidebar

    def draw(self, context):
        layout = self.layout
        props = context.scene.iwg_props

        # Grouping related settings together keeps the panel readable, per
        # this week's UX guidance ("Organizing controls", "Grouping
        # related settings").
        settings_box = layout.box()
        settings_box.label(text="World Settings", icon='WORLD')
        settings_box.prop(props, "seed")
        settings_box.prop(props, "terrain_size")
        settings_box.prop(props, "mountain_strength")
        settings_box.prop(props, "tree_density")

        layout.separator()

        col = layout.column(align=True)
        col.scale_y = 1.4
        col.operator("world.generate", text="Generate World", icon='MESH_GRID')
        col.operator("world.randomize_seed", text="Randomize Seed", icon='FILE_REFRESH')


classes = (WORLDGEN_PT_main_panel,)
