"""
utils.py
========

Small, reusable helpers shared by generator.py and operators.py. Keeping
these separate avoids duplicating boilerplate (finding-or-creating objects,
reading/writing Geometry Nodes group inputs) across the rest of the add-on.

Blender's Geometry Nodes "group interface" API changed between versions
(4.0 introduced node_tree.interface, replacing the old .inputs list from
2.9x-3.x). The helpers below hide that difference so the rest of the
add-on can just call `set_group_input(mod, "Seed", 42)` without caring
which Blender version is running.
"""

import bpy

TERRAIN_OBJECT_NAME = "IWG_Terrain"
TREE_INSTANCE_NAME = "IWG_TreeProxy_v2"
NODE_GROUP_NAME = "IWG_WorldGenerator_v2"
MODIFIER_NAME = "InfiniteWorldGenerator"


def get_or_create_object(name: str, mesh_name: str = None) -> bpy.types.Object:
    """Return the named mesh object, creating an empty mesh object if needed."""
    obj = bpy.data.objects.get(name)
    if obj is not None:
        return obj

    mesh = bpy.data.meshes.new(mesh_name or f"{name}_Mesh")
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    return obj


def get_or_create_tree_proxy() -> bpy.types.Object:
    """
    A tiny cone mesh used as the "tree" instanced onto scattered points.
    Kept in its own hidden object so users can later swap in a real tree
    asset without touching the generator code.
    """
    obj = bpy.data.objects.get(TREE_INSTANCE_NAME)
    if obj is not None:
        return obj

    mesh = bpy.data.meshes.new(f"{TREE_INSTANCE_NAME}_Mesh")
    bm_verts = []
    obj = bpy.data.objects.new(TREE_INSTANCE_NAME, mesh)
    bpy.context.collection.objects.link(obj)

    # Build a simple cone (stand-in "tree") directly with bmesh so the
    # add-on has no external asset dependencies (see assets/README.md).
    import bmesh
    bm = bmesh.new()
    bmesh.ops.create_cone(
        bm,
        cap_ends=True,
        cap_tris=True,
        segments=6,
        radius1=0.3,
        radius2=0.0,
        depth=1.6,
    )
    bm.to_mesh(mesh)
    bm.free()

    mesh.materials.append(get_or_create_tree_material())

    # This object is only ever used as a Geometry Nodes instance source --
    # hide it from the viewport/render so it doesn't clutter the scene.
    obj.hide_render = True
    obj.hide_set(True)
    obj.hide_select = True
    return obj


TREE_MATERIAL_NAME = "IWG_TreeMaterial_v2"
GREEN_COLOR = (0.09, 0.36, 0.12, 1.0)  # foliage green


def get_or_create_tree_material() -> bpy.types.Material:
    """Simple flat-green material for the tree/cone proxy."""
    mat = bpy.data.materials.get(TREE_MATERIAL_NAME)
    if mat is not None:
        return mat

    mat = bpy.data.materials.new(TREE_MATERIAL_NAME)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = GREEN_COLOR
        bsdf.inputs["Roughness"].default_value = 0.9

    # Also set the viewport-display color, which is what Solid shading
    # mode shows (it does NOT evaluate the node tree) -- without this the
    # cones look gray until you switch to Material Preview/Rendered.
    mat.diffuse_color = GREEN_COLOR
    return mat


BIOME_MATERIAL_NAME = "IWG_BiomeMaterial_v2"


def get_or_create_biome_material() -> bpy.types.Material:
    """
    Material that reads the "Biome" per-vertex color attribute (written by
    the Geometry Nodes network based on terrain height) and feeds it
    straight into the Principled BSDF's Base Color, so the desert/
    vegetation/snow gradient painted in Geometry Nodes actually shows up
    in the viewport/render.
    """
    mat = bpy.data.materials.get(BIOME_MATERIAL_NAME)
    if mat is not None:
        return mat

    mat = bpy.data.materials.new(BIOME_MATERIAL_NAME)
    mat.use_nodes = True
    node_tree = mat.node_tree
    node_tree.nodes.clear()

    bsdf = node_tree.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    bsdf.inputs["Roughness"].default_value = 0.9

    color_attr = node_tree.nodes.new("ShaderNodeVertexColor")
    color_attr.location = (-300, 0)
    color_attr.layer_name = "Biome"

    output = node_tree.nodes.new("ShaderNodeOutputMaterial")
    output.location = (300, 0)

    node_tree.links.new(color_attr.outputs["Color"], bsdf.inputs["Base Color"])
    node_tree.links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

    # Solid shading mode (Blender's default viewport mode) does NOT
    # evaluate the node tree at all -- it just shows this flat
    # diffuse_color swatch. Without setting it, the terrain looks plain
    # gray until you switch to Material Preview/Rendered, which makes the
    # height-based color ramp look "broken" even though it's working.
    mat.diffuse_color = (0.5, 0.5, 0.5, 1.0)
    return mat


def find_group_input_id(node_group: bpy.types.NodeTree, socket_name: str):
    """
    Return the identifier for a Geometry Nodes group-input socket by its
    display name, handling both the modern `interface` API (Blender 4.0+)
    and the legacy `.inputs` API (Blender <= 3.6), so the rest of the code
    never has to branch on bpy.app.version.
    """
    if hasattr(node_group, "interface"):
        for item in node_group.interface.items_tree:
            if item.item_type == 'SOCKET' and item.in_out == 'INPUT' \
                    and item.name == socket_name:
                return item.identifier
    else:  # pragma: no cover - legacy Blender fallback
        for socket in node_group.inputs:
            if socket.name == socket_name:
                return socket.identifier
    return None


def set_group_input(modifier: bpy.types.NodesModifier, socket_name: str, value):
    """Set a Geometry Nodes modifier input by its human-readable name."""
    node_group = modifier.node_group
    identifier = find_group_input_id(node_group, socket_name)
    if identifier is None:
        raise KeyError(f"Socket '{socket_name}' not found on {node_group.name}")
    modifier[identifier] = value
