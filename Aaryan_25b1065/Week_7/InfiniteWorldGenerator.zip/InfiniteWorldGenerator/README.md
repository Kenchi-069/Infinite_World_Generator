# Infinite World Generator — Week 7 (v0.1.0)

First working version of the Infinite World Generator Blender add-on.

## What it does

- Adds a **World Gen** tab to the 3D Viewport Sidebar (press `N`).
- Lets you set **Seed**, **Terrain Size**, **Mountain Strength**, and
  **Tree Density** without touching any code.
- **Generate World** builds/updates a terrain mesh with procedural hills
  (via a Geometry Nodes noise displacement) and scatters trees across it.
- **Randomize Seed** picks a new random seed, updates the panel, and
  regenerates the world — so you get a visibly different world each click.

## Install

1. Zip the `InfiniteWorldGenerator/` folder (or use the zip already
   provided alongside this README).
2. In Blender: `Edit > Preferences > Add-ons > Install...`, pick the zip.
3. Enable the "Infinite World Generator" checkbox.
4. In the 3D Viewport, press `N` to open the Sidebar and select the
   **World Gen** tab.

## How the pieces fit together

```
User Input (panel.py properties)
        │
        ▼
operators.py  (Generate World / Randomize Seed buttons)
        │
        ▼
generator.py  (pushes Seed / Terrain Size / Mountain Strength /
               Tree Density into the Geometry Nodes modifier)
        │
        ▼
Geometry Nodes group "IWG_WorldGenerator"
  Grid → Noise-based height offset → Set Position
                                   → Distribute Points on Faces → Instance (tree)
                                   → Join Geometry → Output
```

Python never computes the terrain's vertex positions itself — it only
builds the Geometry Nodes network once (`generator.build_node_group`) and
afterwards just changes that network's *inputs* on every Generate/Randomize
click. This is the "Python as controller, Geometry Nodes as the procedural
engine" pattern from this week's lesson, and it's also why regenerating a
world is fast: Geometry Nodes re-evaluates on the GPU/CPU without Python
touching individual vertices.

The height noise itself is conceptually the same idea as the Week 6
`fractal_noise(seed, x, y)` script: a seeded, deterministic noise function
of (seed, x, y) with multiple octaves. Here it's implemented as a 4D
**Noise Texture** node where X/Y come from the vertex position and W is
the Seed input, so the same seed always reproduces the same terrain and
tree scatter, exactly like Week 6's determinism guarantee.

## Project structure

```
InfiniteWorldGenerator/
├── __init__.py       bl_info + register()/unregister()
├── properties.py     Seed / Terrain Size / Mountain Strength / Tree Density
├── operators.py       WORLDGEN_OT_generate, WORLDGEN_OT_randomize_seed
├── panel.py          Sidebar (N-Panel) UI
├── generator.py       Builds & drives the Geometry Nodes network
├── utils.py          Shared helpers (object/node-group lookup, version-safe
│                      Geometry Nodes interface access)
└── assets/           Reserved for future real tree/rock/building assets
```

## Notes / known limits (first version)

- Grid resolution is fixed at 64×64 vertices for this version; a future
  week can expose it as its own property or drive chunk-based generation
  the way Week 6's `World` class did (generating tiles on demand instead
  of one fixed grid).
- Tested against Blender's Geometry Nodes interface API for 4.0+. If
  you're on Blender ≤3.6, `utils.find_group_input_id` already falls back
  to the legacy `.inputs` API, but `NODE_GROUP_NAME` node types
  (e.g. `GeometryNodeMeshGrid`) still require a fairly recent Blender.
- `village_count` is defined in `properties.py` for the panel but not yet
  wired into `generator.py` — reserved for the settlements stage of the
  pipeline (later week).
