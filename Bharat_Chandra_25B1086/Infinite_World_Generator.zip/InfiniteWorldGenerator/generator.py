import bpy

from . import utils
from . import terrain
from . import biome
from . import vegetation
from . import roads


# Presets: (terrain_size, mountain_strength, tree_density, village_count)
PRESETS = {
    "PLAINS": dict(terrain_size=150.0, mountain_strength=1.0, tree_density=0.15, village_count=1),
    "DESERT": dict(terrain_size=200.0, mountain_strength=1.5, tree_density=0.02, village_count=1),
    "SNOW_MOUNTAINS": dict(terrain_size=180.0, mountain_strength=18.0, tree_density=0.1, village_count=0),
    "TROPICAL_ISLAND": dict(terrain_size=60.0, mountain_strength=4.0, tree_density=0.6, village_count=1),
    "FANTASY_WORLD": dict(terrain_size=200.0, mountain_strength=12.0, tree_density=0.45, village_count=3),
}


def apply_preset(settings, preset_key):
    """Copy a preset's values onto the given WORLDGEN_PG_settings instance."""
    values = PRESETS.get(preset_key)
    if not values:
        return
    for name, value in values.items():
        setattr(settings, name, value)


def build_node_tree():
    """Get the shared Geometry Nodes group, building it the first time."""
    group = bpy.data.node_groups.get(utils.NODE_GROUP_NAME)
    if group is not None:
        return group

    group = bpy.data.node_groups.new(utils.NODE_GROUP_NAME, "GeometryNodeTree")

    # Blender 4.x node group interface API.
    group.interface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
    group.interface.new_socket("Seed", in_out="INPUT", socket_type="NodeSocketFloat")
    group.interface.new_socket("Mountain Strength", in_out="INPUT", socket_type="NodeSocketFloat")
    group.interface.new_socket("Tree Density", in_out="INPUT", socket_type="NodeSocketFloat")
    group.interface.new_socket("Village Count", in_out="INPUT", socket_type="NodeSocketInt")
    group.interface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")

    nodes = group.nodes
    links = group.links

    group_input = nodes.new("NodeGroupInput")
    group_input.location = (-400, 0)
    group_output = nodes.new("NodeGroupOutput")

    geometry = terrain.build(group, group_input, links, location_x=0)
    geometry = biome.build(group, geometry, group_input, links, location_x=1400)
    geometry = vegetation.build(group, geometry, group_input, links, location_x=1600)
    geometry = roads.build(group, geometry, group_input, links, location_x=2800)

    group_output.location = (3000, 0)
    links.new(geometry, group_output.inputs["Geometry"])

    return group


def _set_modifier_input(modifier, node_tree, socket_name, value):
    for item in node_tree.interface.items_tree:
        if item.item_type == "SOCKET" and item.in_out == "INPUT" and item.name == socket_name:
            identifier = item.identifier
            if hasattr(modifier, "properties") and hasattr(modifier.properties, "inputs"):
                getattr(modifier.properties.inputs, identifier).value = value
            else:
                modifier[identifier] = value
            return
    raise KeyError(f"No input socket named '{socket_name}' on {node_tree.name}")


def generate_world(context):
    settings = context.scene.worldgen_settings

    obj = utils.get_or_create_terrain_object()
    utils.rebuild_base_grid(obj, settings.terrain_size)

    node_group = build_node_tree()
    modifier = utils.get_or_create_modifier(obj)
    modifier.node_group = node_group

    _set_modifier_input(modifier, node_group, "Seed", float(settings.seed))
    _set_modifier_input(modifier, node_group, "Mountain Strength", settings.mountain_strength)
    _set_modifier_input(modifier, node_group, "Tree Density", settings.tree_density)
    _set_modifier_input(modifier, node_group, "Village Count", settings.village_count)

    obj.data.update()

    # Make sure the generated world is visible/selected for the artist.
    for other in context.selected_objects:
        other.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj

    return obj


def register():
    pass


def unregister():
    pass
