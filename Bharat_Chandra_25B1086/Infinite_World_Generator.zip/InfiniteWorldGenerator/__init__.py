import bpy

from . import properties
from . import generator
from . import operators
from . import panel

_modules = (properties, operators, panel)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()


if __name__ == "__main__":
    register()
