
import bpy


class WORLDGEN_PG_settings(bpy.types.PropertyGroup):
    seed: bpy.props.IntProperty(
        name="Seed",
        description="Controls the random pattern of the generated world",
        default=0,
        min=0,
    )

    terrain_size: bpy.props.FloatProperty(
        name="Terrain Size",
        description="Overall width/length of the generated terrain, in meters",
        default=100.0,
        min=10.0,
        max=2000.0,
        soft_max=500.0,
    )

    mountain_strength: bpy.props.FloatProperty(
        name="Mountain Strength",
        description="How tall and rugged the terrain's mountains are",
        default=5.0,
        min=0.0,
        max=50.0,
        soft_max=20.0,
    )

    tree_density: bpy.props.FloatProperty(
        name="Tree Density",
        description="How many trees are scattered across the terrain",
        default=0.3,
        min=0.0,
        max=1.0,
    )

    village_count: bpy.props.IntProperty(
        name="Village Count",
        description="Number of settlement locations to reserve on the terrain "
        "(clears vegetation in a radius; road/building generation is a later stage)",
        default=1,
        min=0,
        max=20,
    )

    preset_name: bpy.props.EnumProperty(
        name="Preset",
        description="Quickly load a starting set of values",
        items=[
            ("PLAINS", "Plains", "Gentle, mostly flat terrain with scattered trees"),
            ("DESERT", "Desert", "Large flat terrain with very few trees"),
            ("SNOW_MOUNTAINS", "Snow Mountains", "Tall, rugged mountains with sparse trees"),
            ("TROPICAL_ISLAND", "Tropical Island", "Small terrain, dense vegetation"),
            ("FANTASY_WORLD", "Fantasy World", "Dramatic mountains, dense forest, several villages"),
        ],
        default="PLAINS",
    )


def register():
    bpy.utils.register_class(WORLDGEN_PG_settings)
    bpy.types.Scene.worldgen_settings = bpy.props.PointerProperty(type=WORLDGEN_PG_settings)


def unregister():
    del bpy.types.Scene.worldgen_settings
    bpy.utils.unregister_class(WORLDGEN_PG_settings)
