def build(node_tree, group_input, links, location_x=0):
    nodes = node_tree.nodes

    noise = nodes.new("GeometryNodeInputPosition")
    noise.location = (location_x, 200)

    noise_tex = nodes.new("ShaderNodeTexNoise")
    noise_tex.location = (location_x + 180, 100)
    noise_tex.inputs["Scale"].default_value = 1.5
    noise_tex.noise_dimensions = "4D"

    links.new(noise.outputs["Position"], noise_tex.inputs["Vector"])
    links.new(group_input.outputs["Seed"], noise_tex.inputs["W"])

    # Push the noise (0..1) into a signed -1..1 range so terrain has both
    # hills and valleys instead of only rising upward.
    map_range = nodes.new("ShaderNodeMapRange")
    map_range.location = (location_x + 380, 100)
    map_range.inputs["To Min"].default_value = -1.0
    map_range.inputs["To Max"].default_value = 1.0
    links.new(noise_tex.outputs["Fac"], map_range.inputs["Value"])

    strength_multiply = nodes.new("ShaderNodeMath")
    strength_multiply.operation = "MULTIPLY"
    strength_multiply.location = (location_x + 580, 100)
    links.new(map_range.outputs["Result"], strength_multiply.inputs[0])
    links.new(group_input.outputs["Mountain Strength"], strength_multiply.inputs[1])

    combine_offset = nodes.new("ShaderNodeCombineXYZ")
    combine_offset.location = (location_x + 780, 100)
    links.new(strength_multiply.outputs["Value"], combine_offset.inputs["Z"])

    set_position = nodes.new("GeometryNodeSetPosition")
    set_position.location = (location_x + 980, 250)
    links.new(group_input.outputs["Geometry"], set_position.inputs["Geometry"])
    links.new(combine_offset.outputs["Vector"], set_position.inputs["Offset"])

    set_position.inputs["Selection"].default_value = True

    # Smooth shading reads better on procedural terrain than flat faces.
    shade_smooth = nodes.new("GeometryNodeSetShadeSmooth")
    shade_smooth.location = (location_x + 1180, 250)
    links.new(set_position.outputs["Geometry"], shade_smooth.inputs["Geometry"])
    shade_smooth.inputs["Shade Smooth"].default_value = True

    return shade_smooth.outputs["Geometry"]
