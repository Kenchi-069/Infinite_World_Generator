def _build_simple_tree(node_tree, location):
    nodes = node_tree.nodes
    links = node_tree.links

    trunk = nodes.new("GeometryNodeMeshCylinder")
    trunk.location = (location[0], location[1])
    trunk.inputs["Radius"].default_value = 0.05
    trunk.inputs["Depth"].default_value = 0.6

    foliage = nodes.new("GeometryNodeMeshCone")
    foliage.location = (location[0], location[1] - 200)
    foliage.inputs["Radius Bottom"].default_value = 0.35
    foliage.inputs["Depth"].default_value = 0.9

    move_foliage = nodes.new("GeometryNodeTransform")
    move_foliage.location = (location[0] + 200, location[1] - 200)
    move_foliage.inputs["Translation"].default_value = (0, 0, 0.75)
    links.new(foliage.outputs["Mesh"], move_foliage.inputs["Geometry"])

    join = nodes.new("GeometryNodeJoinGeometry")
    join.location = (location[0] + 420, location[1] - 80)
    links.new(trunk.outputs["Mesh"], join.inputs["Geometry"])
    links.new(move_foliage.outputs["Geometry"], join.inputs["Geometry"])

    return join.outputs["Geometry"]


def build(node_tree, geometry_socket, group_input, links, location_x=0):
    nodes = node_tree.nodes

    distribute = nodes.new("GeometryNodeDistributePointsOnFaces")
    distribute.location = (location_x, 0)
    distribute.distribute_method = "RANDOM"
    links.new(geometry_socket, distribute.inputs["Mesh"])
    links.new(group_input.outputs["Tree Density"], distribute.inputs["Density"])
    links.new(group_input.outputs["Seed"], distribute.inputs["Seed"])

    tree_geometry = _build_simple_tree(node_tree, (location_x, -400))

    rotate_align = nodes.new("FunctionNodeRandomValue")
    rotate_align.location = (location_x + 220, -150)
    rotate_align.data_type = "FLOAT_VECTOR"
    rotate_align.inputs[0].default_value = (0, 0, 0)
    rotate_align.inputs[1].default_value = (0, 0, 6.2831853)  # random yaw only

    instance = nodes.new("GeometryNodeInstanceOnPoints")
    instance.location = (location_x + 460, 0)
    links.new(distribute.outputs["Points"], instance.inputs["Points"])
    links.new(tree_geometry, instance.inputs["Instance"])
    links.new(rotate_align.outputs["Value"], instance.inputs["Rotation"])

    realize = nodes.new("GeometryNodeRealizeInstances")
    realize.location = (location_x + 680, 0)
    links.new(instance.outputs["Instances"], realize.inputs["Geometry"])

    join_final = nodes.new("GeometryNodeJoinGeometry")
    join_final.location = (location_x + 900, 150)
    links.new(geometry_socket, join_final.inputs["Geometry"])
    links.new(realize.outputs["Geometry"], join_final.inputs["Geometry"])

    return join_final.outputs["Geometry"]
