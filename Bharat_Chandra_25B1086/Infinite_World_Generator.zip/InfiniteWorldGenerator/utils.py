"""Small helper functions used by the other modules.

Keeping these in one place avoids duplicating boilerplate (finding or
creating objects, node groups, etc.) inside operators.py and generator.py.
"""

import random
import bpy

TERRAIN_OBJECT_NAME = "InfiniteWorld_Terrain"
NODE_GROUP_NAME = "InfiniteWorldGenerator_Nodes"


def get_or_create_terrain_object():
    """Return the terrain mesh object, creating a base grid if needed."""
    obj = bpy.data.objects.get(TERRAIN_OBJECT_NAME)
    if obj is not None:
        return obj

    mesh = bpy.data.meshes.new(TERRAIN_OBJECT_NAME + "_Mesh")
    obj = bpy.data.objects.new(TERRAIN_OBJECT_NAME, mesh)
    bpy.context.collection.objects.link(obj)
    return obj


def rebuild_base_grid(obj, size, resolution=64):
    import bmesh

    bm = bmesh.new()
    bmesh.ops.create_grid(
        bm,
        x_segments=resolution,
        y_segments=resolution,
        size=size / 2.0,
    )
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


def get_or_create_modifier(obj):
    for mod in obj.modifiers:
        if mod.type == "NODES":
            return mod

    mod = obj.modifiers.new(name="Infinite World Generator", type="NODES")
    return mod


def random_seed():
    return random.randint(0, 1_000_000)
