import bpy

from . import generator
from . import utils


class WORLDGEN_generate(bpy.types.Operator):
    """Read the current settings and (re)generate the procedural world"""

    bl_idname = "world.generate"
    bl_label = "Generate World"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        generator.generate_world(context)
        self.report({"INFO"}, "World generated.")
        return {"FINISHED"}


class WORLDGEN_randomize_seed(bpy.types.Operator):
    """Pick a new random seed and regenerate the world with it"""

    bl_idname = "world.randomize_seed"
    bl_label = "Randomize Seed"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.worldgen_settings
        settings.seed = utils.random_seed()
        generator.generate_world(context)
        self.report({"INFO"}, f"New seed: {settings.seed}")
        return {"FINISHED"}


class WORLDGEN_apply_preset(bpy.types.Operator):
    """Load one of the built-in world presets into the current settings"""

    bl_idname = "world.apply_preset"
    bl_label = "Apply Preset"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.worldgen_settings
        generator.apply_preset(settings, settings.preset_name)
        generator.generate_world(context)
        self.report({"INFO"}, f"Preset '{settings.preset_name.title()}' applied.")
        return {"FINISHED"}


class WORLDGEN_reset_settings(bpy.types.Operator):
    """Reset all world generation settings back to their defaults"""

    bl_idname = "world.reset_settings"
    bl_label = "Reset Settings"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.worldgen_settings
        defaults = settings.bl_rna.properties
        for prop_name in ("seed", "terrain_size", "mountain_strength", "tree_density", "village_count"):
            setattr(settings, prop_name, defaults[prop_name].default)
        self.report({"INFO"}, "Settings reset to defaults.")
        return {"FINISHED"}


class WORLDGEN_clear_scene(bpy.types.Operator):
    """Remove the generated terrain object from the scene"""

    bl_idname = "world.clear_scene"
    bl_label = "Clear World"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = bpy.data.objects.get(utils.TERRAIN_OBJECT_NAME)
        if obj is not None:
            mesh = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if mesh and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
            self.report({"INFO"}, "Generated world removed.")
        else:
            self.report({"INFO"}, "Nothing to clear.")
        return {"FINISHED"}


_classes = (
    WORLDGEN_generate,
    WORLDGEN_randomize_seed,
    WORLDGEN_apply_preset,
    WORLDGEN_reset_settings,
    WORLDGEN_clear_scene,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
