import bpy


class WORLDGEN_PT_main_panel(bpy.types.Panel):
    bl_label = "Infinite World Generator"
    bl_idname = "WORLDGEN_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "World Gen"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.worldgen_settings

        preset_box = layout.box()
        preset_box.label(text="Preset", icon="PRESET")
        row = preset_box.row(align=True)
        row.prop(settings, "preset_name", text="")
        preset_box.operator("world.apply_preset", icon="CHECKMARK")

        terrain_box = layout.box()
        terrain_box.label(text="Terrain", icon="MESH_GRID")
        terrain_box.prop(settings, "seed")
        terrain_box.prop(settings, "terrain_size")
        terrain_box.prop(settings, "mountain_strength")

        veg_box = layout.box()
        veg_box.label(text="Vegetation & Settlements", icon="OUTLINER_OB_FORCE_FIELD")
        veg_box.prop(settings, "tree_density")
        veg_box.prop(settings, "village_count")

        layout.separator()
        col = layout.column(align=True)
        col.scale_y = 1.4
        col.operator("world.generate", icon="WORLD")
        col.operator("world.randomize_seed", icon="FILE_REFRESH")

        row = layout.row(align=True)
        row.operator("world.reset_settings", icon="LOOP_BACK")
        row.operator("world.clear_scene", icon="TRASH")


_classes = (WORLDGEN_PT_main_panel,)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
