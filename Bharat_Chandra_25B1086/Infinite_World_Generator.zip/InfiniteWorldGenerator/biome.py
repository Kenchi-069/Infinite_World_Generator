def build(node_tree, geometry_socket, group_input, links, location_x=0):
    return geometry_socket
